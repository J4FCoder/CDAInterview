Hi <strong><?php echo e($receiver_name); ?></strong>
<br>
<p><?php echo e($body); ?></p>
<br>
<p>This email was from <?php echo e($sender_name); ?> with this email address: <?php echo e($sender_email); ?></p>
<?php /**PATH /home/nahid/PhpstormProjects/cdainterview/cdainterview/resources/views/mailer.blade.php ENDPATH**/ ?>
