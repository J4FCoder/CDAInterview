Hi <strong>{{$receiver_name}}</strong>
<br>
<p>{{$body}}</p>
<br>
<p>This email was from {{$sender_name}} with this email address: {{$sender_email}}</p>
